<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update Mahasiswa</title>
</head>
<body>
<?php
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $db = 'informatika';

    $con = mysqli_connect($host, $user, $password, $db);
    // mengambil nim dari URL

    $nim2 = $_GET['nim'];
    $cari = "SELECT*FROM mahasiswa WHERE nim = '$nim2'";
    $hasilCari = mysqli_query($con, $cari);

    // mengambil 1 baris array
    $data =mysqli_fetch_array($hasilCari);

    // var_dump($data);
    // echo $data['nim'];


    
    ?>
    <h3>Update Data Mahasiswa</h3>
    <table>
        <form action="update.php" method="post">
        <tr>
            <td>Nim</td>
            <td>:</td>
            <td><input type="text" name="nim" size='10' value="<?php echo $data['nim'];?>"></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" value="<?php echo $data['nama'];?>"></td>
        </tr>
        <tr>
            <td>Kelas</td>
            <td>:</td>
            <td><input type="radio" name="kelas" value="A" checked> A
                <input type="radio" name="kelas" value="B" checked> B
                <input type="radio" name="kelas" value="C" checked> C</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><input type="text" name="alamat" size="40" value="<?php echo $data['alamat'];?>"></td>
        </tr>
        <tr>
            <td><input type="submit" name="submit" value="Update"></td>
        </tr>    
    </table>


    <?php
    error_reporting(E_ALL ^E_NOTICE);

    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $alamat = $_POST['alamat'];
    $submit = $_POST['submit'];
    $update = "UPDATE mahasiswa SET nim='$nim', nama='$nama', kelas='$kelas', alamat='$alamat' WHERE nim='$nim'";

    if($submit){
        if($nim=='' | $nama=='' | $alamat==''){
            echo "Form tidak Boleh kosong";
        }else{
            mysqli_query($con, $update);
            echo "Data berhasil diupdate";
        }
    }

    ?>
    
</body>
</html>
    
    
</body>
</html>
