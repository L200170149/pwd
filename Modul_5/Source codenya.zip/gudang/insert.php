<!DOCTYPE html>
<?php
    $con = mysqli_connect('localhost', 'root', '', 'toko');
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gudang</title>
</head>
<body>
    <h3>Insert Data gudang</h3>
    <form action="" method="post">
        <table>
            <tr>
                <td>kode gudang</td>
                <td>:</td>
                <td><input type="text" name="kode_gudang"></td>
            </tr>
            <tr>
                <td>nama gudang</td>
                <td>:</td>
                <td><input type="text" name="nama_gudang"></td>
            </tr>
            <tr>
                <td>Lokasi</td>
                <td>:</td>
                <td><input type="text" name="lokasi_gudang"></td>
            </tr>
            <tr>
                
                <td><input type="submit" name="submit" value="Submit"></td>
            </tr>
        </table>
        
    </form>
    <?php
    error_reporting(E_ALL ^E_NOTICE);
    $kode_gudang = $_POST['kode_gudang'];
    $nama_gudang = $_POST['nama_gudang'];
    $lokasi_gudang = $_POST['lokasi_gudang'];
    $submit = $_POST['submit'];

    $insert = "INSERT INTO gudang (kode_gudang, nama_gudang, lokasi) VALUES ('$kode_gudang', '$nama_gudang', '$lokasi_gudang') ";
    if($submit){
        if($kode_gudang == "" | $nama_gudang == "" | $lokasi_gudang == "") {
            echo "Form harus di isi lengkap";
        }else{
            mysqli_query($con, $insert);
            if(mysqli_query){
                echo "data berhasil dimasukan";
                header('Location: index.php');
            }
        }
    }


    ?>
</body>
</html>
