<?php
        
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $db = 'informatika';
        
        $con = mysqli_connect($host, $user, $password, $db);
    
        
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MAntull ya mak</title>
</head>
<body>
    <h3>Data Mahasiswa</h3>
    <a href="tugas11.php">Tambahkan data mahasiswa</a><br><br>

    <table border="1">
        <tr>
            <th>NIm</th>
            <th>Nama</th>
            <th>kelas</th>
            <th>alamat</th>
            <th colspan="1">Keterangan</th>
        </tr>

        <?php
            $cari = "SELECT * FROM mahasiswa order by nim";
            $hasilCari = mysqli_query($con, $cari);
            // var_dump($hasilCari);

            while ($data = mysqli_fetch_array($hasilCari)){
                echo "
                    <tr>
                        <td> $data[nim]</td>
                        <td> $data[nama]</td>
                        <td> $data[kelas]</td>
                        <td> $data[alamat]</td>
                        <td> <a href='update.php?nim=$data[nim]'>Ubah</a></td>
                        
                        

                ";
            }
        ?>
    </table>
    
</body>
</html>