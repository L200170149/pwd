<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update Mahasiswa</title>
</head>
<body>
<?php
     $con = mysqli_connect('localhost', 'root', '', 'toko');
    // mengambil nim dari URL
    $kode_gudang = $_GET['kode_gudang'];

    $getData = "SELECT * FROM gudang WHERE kode_gudang = '$kode_gudang'";
    $dataMentah = mysqli_query($con, $getData);

    $data =mysqli_fetch_array($dataMentah);

    // var_dump($data);
    // echo $data['nim'];


    
    ?>
    <table>
<form action="update.php" method="post">
    <tr>
        <td>kode gudang</td>
        <td>:</td>
        <td><input type="text" name="kode_gudang" readonly="readonly" value="<?php echo $data['kode_gudang']; ?>"></td>

    </tr>
    <tr>
        <td>Nama gudang</td>
        <td>:</td>
        <td><input type="text" name="nama_gudang" value="<?php echo $data['nama_gudang'];?>"></td>

    </tr>
    <tr>
        <td>Lokasi</td>
        <td>:</td>
        <td><input type="text" name="lokasi" value="<?php echo $data['lokasi']; ?>"></td>

    </tr>
    <tr>
        <td><input type="submit" value="update" name="submit"></td>

    </tr>
    <?php
         error_reporting(E_ALL ^E_NOTICE);
     
         $kode_gudang = $_POST['kode_gudang'];
         $nama_gudang = $_POST['nama_gudang'];
         $lokasi = $_POST['lokasi'];
         $submit = $_POST['submit'];
         $update = "UPDATE gudang SET kode_gudang='$kode_gudang', nama_gudang='$nama_gudang', lokasi='$lokasi' WHERE kode_gudang=$kode_gudang";
     
         if($submit){
             if($kode_gudang=='' | $nama_gudang=='' | $lokasi==''){
                 echo "Form tidak Boleh kosong";
             }else{
                 mysqli_query($con, $update);
                 echo "Data berhasil diupdate";
                //  header('Location: index.php');
                echo"
                <script>
                    alert('data berhasi dihapus');
                    document.location.href='index.php'
                </script>
            ";
             }
         }
     
     
    ?>
</form>
</table>
</body>
</html>