<?php
        
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $db = 'toko';
        
        $con = mysqli_connect($host, $user, $password, $db);
        //megambil data dari url
	
        
        
        $kodeGudang = $_GET['kode_gudang'];
        $hapus = "DELETE FROM gudang WHERE kode_gudang = $kodeGudang";
        $data = mysqli_query($con, $hapus);

        if($data >0){
            echo"
                <script>
                    alert('data berhasi dihapus');
                    document.location.href='index.php'
                </script>
            ";
        }

    ?>