
<!DOCTYPE html>
<?php
    $con = mysqli_connect('localhost', 'root', '', 'toko');
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tampil data gudang</title>
</head>
<body>
    <h3>Data Gudang</h3>
    <a href="insert.php">Tambah data Gudang</a><br><br>   
    <table border="1">
        <tr>
            <th>kode gudang</th>
            <th>nama gudang</th>
            <th>lokasi</th>
            <th colspan="2">Aksi</th>

        </tr>

        <?php
            error_reporting(E_ALL ^E_NOTICE);
            $getData = "SELECT * FROM gudang";
            $dataMentah = mysqli_query($con, $getData);
            
            // var_dump($data);
            

            while($data = mysqli_fetch_array($dataMentah)){
                echo "
                    <tr> 
                        <td>$data[kode_gudang]</td>
                        <td>$data[nama_gudang]</td>
                        <td>$data[lokasi]</td>
                        <td> <a href='update.php?kode_gudang=$data[kode_gudang]'>Edit</a></td>
                        <td> <a href='delete.php?kode_gudang=$data[kode_gudang]'>Delete</a></td>

                    </tr>
                ";
            }
        ?>
    
    </table>
</body>
</html>
