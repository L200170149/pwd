<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tugas 1</title>
    <?php
        
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $db = 'informatika';
        
        $conn = mysqli_connect($host, $user, $password, $db);
        
        
    ?>
</head>
<body>
    <h3>Data Mahasiswa</h3>
    <table>
        <form action="tugas11.php" method="post">
        <tr>
            <td>Nim</td>
            <td>:</td>
            <td><input type="text" name="nim"></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama"></td>
        </tr>
        <tr>
            <td>Kelas</td>
            <td>:</td>
            <td><input type="radio" name="kelas" value="A" checked> A
                <input type="radio" name="kelas" value="B" checked> B
                <input type="radio" name="kelas" value="C" checked> C</td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><input type="text" name="alamat" size="40"></td>
        </tr>
        <tr>
            <td><input type="submit" name="submit" value="kirim"></td>
        </tr>    
    </table>

    <?php
    error_reporting(E_ALL ^E_NOTICE);

    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $alamat = $_POST['alamat'];
    $submit = $_POST['submit'];
    $input = "INSERT INTO mahasiswa (nim, nama, kelas, alamat) values ('$nim','$nama', '$kelas','$alamat' )";

    if($submit){
        if($nim=='' | $nama=='' | $alamat==''){
            echo "Form tidak Boleh kosong";
        }else{
            mysqli_query($conn, $input);
            echo "Data berhasil dimasukan";
        }
    }

    ?>
    
</body>
</html>