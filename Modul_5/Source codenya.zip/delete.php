<?php
        echo "<h3>Delete Data gudang</h3>";
        $host = 'localhost';
        $user = 'root';
        $password = '';
        $db = 'informatika';
        
        $con = mysqli_connect($host, $user, $password, $db);
        //megambil data dari url
        
        $nim = $_GET['nim'];
        $hapus = "DELETE FROM mahasiswa WHERE nim= '$nim'";
        $data = mysqli_query($con, $hapus);

        if($data >0){
            echo"
                <script>
                    alert('data berhasi dihapus');
                    document.location.href='index.php'
                </script>
            ";
        }

    ?>